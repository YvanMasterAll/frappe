from __future__ import unicode_literals
import frappe

def execute():
	"""
		rename feedback request documents,
		update the feedback request and save the rating and communication
		reference in Feedback Request document
	"""
	return
